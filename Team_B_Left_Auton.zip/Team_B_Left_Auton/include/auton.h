#pragma once

void runAutonomous();
void spinIntake();
void stopIntake();
